// A pharmacist writes prescriptions to people. 

// A cashier collects cash and returns cash to pharmacy 

// A manager manages employees 

// A manager can sometimes work as a cashier and a pharmacist. 



function Phamarcy (name, amount){
    this.name=name
    this.amount=amount

}


let cashier=function(){
    console.log(this.amount);
}

let pharmicist=function(){
    console.log(this.name, "the ")
       }


let phamrcy=new Phamarcy("Emmanuel", 56)
let manager={}



Object.assign(manager,phamrcy)
Object.assign(manager,pharmicist)
Object.assign(manager,cashier)

console.log(manager)
