


What does constructive criticism mean to you? 
it means giving positive criticism towards certain aspects of discusion. 
For instances, teling someone about he/he poor communication skills.