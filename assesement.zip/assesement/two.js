// Given a string S of length N, write a JavaScript function that transforms the string by reversing characters in groups of four and returns the transformed string. 

let str="Lorem at";

function strReverse(){

let strSpl=str.split(" ").reverse().join("")

console.log(strSpl);

let smallSlice=strSpl.slice(6)
let splAgain=strSpl.split("",6).reverse().join("")

return splAgain.concat(smallSlice)

}
strReverse()